from __future__ import annotations

import sqlite3
from pathlib import Path


SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS jobs (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  url             TEXT NOT NULL UNIQUE,
  status          TEXT NOT NULL DEFAULT 'PENDING',
  attempts        INTEGER NOT NULL DEFAULT 0,
  last_error      TEXT,
  lease_until_utc TEXT,                             -- ISO8601 UTC
  lease_id        TEXT,                             -- UUID per claim
  last_heartbeat_utc TEXT,                          -- ISO8601 UTC
  created_at_utc  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at_utc  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  screenshot_path TEXT,
  final_url       TEXT,
  load_ms         INTEGER
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_lease ON jobs(lease_until_utc);

"""


def init_db(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.executescript(SCHEMA)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Initialize the run SQLite DB.")
    p.add_argument("--db", required=True, help="Path to SQLite DB file (per run).")
    args = p.parse_args()

    init_db(Path(args.db))
    print(f"Initialized DB: {args.db}")
