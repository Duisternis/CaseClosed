from __future__ import annotations

import random
import sqlite3
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

UTC = timezone.utc


def utc_now() -> datetime:
    return datetime.now(tz=UTC)


def to_iso(dt: datetime) -> str:
    # Always store UTC ISO8601 with Z
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def from_iso(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=UTC)


@dataclass(frozen=True)
class Job:
    id: int
    url: str
    status: str
    attempts: int
    lease_until_utc: Optional[str]
    lease_id: str


def connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=5000;")
    ensure_schema(conn)
    return conn


def _retry_locked(
    conn: sqlite3.Connection,
    fn,
    retries: int = 5,
    base_sleep: float = 0.05,
    max_sleep: float = 0.5,
):
    last_err = None
    for attempt in range(retries):
        try:
            return fn()
        except sqlite3.OperationalError as e:
            if "locked" not in str(e).lower():
                raise
            last_err = e
            try:
                conn.rollback()
            except Exception:
                pass
            sleep = min(max_sleep, base_sleep * (2 ** attempt)) + random.uniform(0, base_sleep)
            time.sleep(sleep)
    if last_err:
        raise last_err


def ensure_schema(conn: sqlite3.Connection) -> None:
    # Add lease_id column if missing.
    cur = conn.execute("PRAGMA table_info(jobs);")
    cols = {row[1] for row in cur.fetchall()}
    if not cols:
        return
    if "lease_id" not in cols:
        conn.execute("ALTER TABLE jobs ADD COLUMN lease_id TEXT;")
        conn.commit()
    if "last_heartbeat_utc" not in cols:
        conn.execute("ALTER TABLE jobs ADD COLUMN last_heartbeat_utc TEXT;")
        conn.commit()

    conn.executescript(
        """
        """
    )
    conn.commit()


def claim_job(conn: sqlite3.Connection, lease_seconds: int = 120) -> Optional[Job]:
    """
    Atomically claim one job that is:
    - PENDING
    - or IN_PROGRESS with expired lease
    - or RETRY_WAIT with expired lease
    """
    def _op() -> Optional[Job]:
        now = utc_now()
        lease_until = to_iso(now + timedelta(seconds=lease_seconds))
        now_iso = to_iso(now)

        lease_id = uuid.uuid4().hex
        cur = conn.cursor()
        cur.execute("BEGIN IMMEDIATE;")

        # Pick one eligible job
        cur.execute(
            """
            SELECT id, url, status, attempts, lease_until_utc
            FROM jobs
            WHERE
              status IN ('PENDING', 'RETRY_WAIT')
              AND (lease_until_utc IS NULL OR lease_until_utc < ?)
            OR
              status = 'IN_PROGRESS'
              AND lease_until_utc IS NOT NULL AND lease_until_utc < ?
            ORDER BY
              CASE status
                WHEN 'PENDING' THEN 0
                WHEN 'RETRY_WAIT' THEN 1
                WHEN 'IN_PROGRESS' THEN 2
                ELSE 9
              END,
              id
            LIMIT 1;
            """,
            (now_iso, now_iso),
        )
        row = cur.fetchone()
        if not row:
            conn.commit()
            return None

        job_id = int(row["id"])

        # Claim it
        cur.execute(
            """
            UPDATE jobs
            SET status='IN_PROGRESS',
                lease_until_utc=?,
                lease_id=?,
                last_heartbeat_utc=?,
                updated_at_utc=?
            WHERE id=?;
            """,
            (lease_until, lease_id, now_iso, now_iso, job_id),
        )

        conn.commit()
        return Job(
            id=job_id,
            url=row["url"],
            status="IN_PROGRESS",
            attempts=int(row["attempts"]),
            lease_until_utc=lease_until,
            lease_id=lease_id,
        )

    return _retry_locked(conn, _op)


def heartbeat(conn: sqlite3.Connection, job_id: int, lease_id: str, lease_seconds: int = 120) -> bool:
    """Extend lease while working so reaper/other workers don't steal it."""
    def _op() -> bool:
        now = utc_now()
        lease_until = to_iso(now + timedelta(seconds=lease_seconds))
        now_iso = to_iso(now)
        cur = conn.execute(
            """
            UPDATE jobs
            SET lease_until_utc=?, last_heartbeat_utc=?, updated_at_utc=?
            WHERE id=? AND status='IN_PROGRESS' AND lease_id=?;
            """,
            (lease_until, now_iso, now_iso, job_id, lease_id),
        )
        conn.commit()
        return cur.rowcount == 1

    return _retry_locked(conn, _op)


def mark_done(
    conn: sqlite3.Connection,
    job_id: int,
    lease_id: str,
    screenshot_path: str,
    final_url: Optional[str] = None,
    load_ms: Optional[int] = None,
) -> bool:
    def _op() -> bool:
        now_iso = to_iso(utc_now())
        cur = conn.execute(
            """
            UPDATE jobs
            SET status='DONE',
                lease_until_utc=NULL,
                lease_id=NULL,
                last_heartbeat_utc=NULL,
                screenshot_path=?,
                final_url=COALESCE(?, final_url),
                load_ms=COALESCE(?, load_ms),
                last_error=NULL,
                updated_at_utc=?
            WHERE id=? AND status='IN_PROGRESS' AND lease_id=?;
            """,
            (screenshot_path, final_url, load_ms, now_iso, job_id, lease_id),
        )
        conn.commit()
        return cur.rowcount == 1

    return _retry_locked(conn, _op)


def mark_failed(
    conn: sqlite3.Connection,
    job_id: int,
    lease_id: str,
    error: str,
    permanent: bool,
    backoff_seconds: int = 60,
    max_attempts: int = 3,
) -> bool:
    """
    If permanent=True -> FAILED
    Else -> RETRY_WAIT until now+backoff, unless attempts would exceed max_attempts -> FAILED
    """
    def _op() -> bool:
        now = utc_now()
        now_iso = to_iso(now)

        cur = conn.cursor()
        cur.execute("SELECT attempts FROM jobs WHERE id=?;", (job_id,))
        row = cur.fetchone()
        attempts = int(row["attempts"]) if row else 0
        next_attempts = attempts + 1

        if permanent or next_attempts >= max_attempts:
            cur.execute(
                """
                UPDATE jobs
                SET status='FAILED',
                    attempts=?,
                    last_error=?,
                    lease_until_utc=NULL,
                    lease_id=NULL,
                    last_heartbeat_utc=NULL,
                    updated_at_utc=?
                WHERE id=? AND status='IN_PROGRESS' AND lease_id=?;
                """,
                (next_attempts, error[:2000], now_iso, job_id, lease_id),
            )
        else:
            retry_at = to_iso(now + timedelta(seconds=backoff_seconds))
            cur.execute(
                """
                UPDATE jobs
                SET status='RETRY_WAIT',
                    attempts=?,
                    last_error=?,
                    lease_until_utc=?,
                    lease_id=NULL,
                    last_heartbeat_utc=NULL,
                    updated_at_utc=?
                WHERE id=? AND status='IN_PROGRESS' AND lease_id=?;
                """,
                (next_attempts, error[:2000], retry_at, now_iso, job_id, lease_id),
            )

        conn.commit()
        return cur.rowcount == 1

    return _retry_locked(conn, _op)

def reap_stale_in_progress(conn: sqlite3.Connection) -> int:
    """
    If a job is IN_PROGRESS but its lease expired, put it back to PENDING.
    Returns number of rescued jobs.
    """
    def _op() -> int:
        now_iso = to_iso(utc_now())
        cur = conn.cursor()
        cur.execute(
            """
            SELECT id FROM jobs
            WHERE status='IN_PROGRESS'
              AND lease_until_utc IS NOT NULL
              AND lease_until_utc < ?;
            """,
            (now_iso,),
        )
        ids = [int(r[0]) for r in cur.fetchall()]
        if not ids:
            return 0

        cur.execute(
            f"""
            UPDATE jobs
            SET status='PENDING',
                lease_until_utc=NULL,
                lease_id=NULL,
                last_heartbeat_utc=NULL,
                updated_at_utc=?
            WHERE id IN ({",".join("?" for _ in ids)});
            """,
            (now_iso, *ids),
        )
        conn.commit()
        return len(ids)

    return _retry_locked(conn, _op)


def reap_stuck_in_progress(conn: sqlite3.Connection, stale_seconds: int = 300) -> int:
    """
    If a job is IN_PROGRESS but no heartbeat within stale_seconds, put it back to PENDING.
    """
    def _op() -> int:
        now = utc_now()
        now_iso = to_iso(now)
        cutoff = to_iso(now - timedelta(seconds=stale_seconds))
        cur = conn.cursor()
        cur.execute(
            """
            SELECT id FROM jobs
            WHERE status='IN_PROGRESS'
              AND last_heartbeat_utc IS NOT NULL
              AND last_heartbeat_utc < ?;
            """,
            (cutoff,),
        )
        ids = [int(r[0]) for r in cur.fetchall()]
        if not ids:
            return 0

        cur.execute(
            f"""
            UPDATE jobs
            SET status='PENDING',
                lease_until_utc=NULL,
                lease_id=NULL,
                last_heartbeat_utc=NULL,
                updated_at_utc=?
            WHERE id IN ({",".join("?" for _ in ids)});
            """,
            (now_iso, *ids),
        )
        conn.commit()
        return len(ids)

    return _retry_locked(conn, _op)


def count_remaining(conn: sqlite3.Connection) -> int:
    cur = conn.execute(
        "SELECT COUNT(*) FROM jobs WHERE status IN ('PENDING','RETRY_WAIT','IN_PROGRESS');"
    )
    row = cur.fetchone()
    return int(row[0]) if row else 0


def count_ready(conn: sqlite3.Connection) -> int:
    now_iso = to_iso(utc_now())
    cur = conn.execute(
        """
        SELECT COUNT(*) FROM jobs
        WHERE
          status = 'PENDING'
          OR (status = 'RETRY_WAIT' AND (lease_until_utc IS NULL OR lease_until_utc < ?));
        """,
        (now_iso,),
    )
    row = cur.fetchone()
    return int(row[0]) if row else 0
