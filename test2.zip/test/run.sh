#!/usr/bin/env bash
set -euo pipefail

MAX_RESTARTS=5
RESTART_DELAY=5
VENV_DIR=".venv"

PYTHON_BIN="python3"
if ! command -v "${PYTHON_BIN}" >/dev/null 2>&1; then
  PYTHON_BIN="python"
fi

if [ ! -d "${VENV_DIR}" ]; then
  echo "[runner] creating venv (${VENV_DIR})"
  "${PYTHON_BIN}" -m venv "${VENV_DIR}"
fi

source "${VENV_DIR}/bin/activate"

python -c "import playwright" >/dev/null 2>&1 || python -m pip install -r requirements.txt

count=0
while true; do
  echo "[runner] starting (attempt $((count + 1))/${MAX_RESTARTS})"
  python main.py "$@"
  exit_code=$?

  if [ $exit_code -eq 0 ]; then
    echo "[runner] completed successfully"
    exit 0
  fi

  count=$((count + 1))
  if [ $count -ge $MAX_RESTARTS ]; then
    echo "[runner] reached max restarts (${MAX_RESTARTS}), exiting with code ${exit_code}"
    exit $exit_code
  fi

  echo "[runner] exited with code ${exit_code}, restarting in ${RESTART_DELAY}s..."
  sleep $RESTART_DELAY
done
