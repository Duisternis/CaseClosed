from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import datetime
from multiprocessing import Process
from pathlib import Path
from typing import TextIO

from runner.core.db import connect, count_ready, count_remaining
from runner.core.init_db import init_db
from runner.core.load_csv import load_urls_from_dir
from runner.cli.reaper_loop import main as reaper_main
from runner.cli.playwright_worker import main as worker_main


def ts_name() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")


def parse_simple_config(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    data: dict[str, object] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or ":" not in line:
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip()
        if not val:
            data[key] = ""
            continue
        if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
            data[key] = val[1:-1]
            continue
        low = val.lower()
        if low in ("true", "false"):
            data[key] = (low == "true")
            continue
        try:
            if "." in val:
                data[key] = float(val)
            else:
                data[key] = int(val)
            continue
        except ValueError:
            data[key] = val
    return data

def log_line(out: TextIO, msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out.write(f"[{ts}] {msg}\n")
    out.flush()


def ensure_dirs() -> None:
    Path("out/runs").mkdir(parents=True, exist_ok=True)
    Path("out/screenshots").mkdir(parents=True, exist_ok=True)
    Path("out/logs").mkdir(parents=True, exist_ok=True)


def worker_entry(
    db: str,
    browser: str | None,
    screenshots: str,
    worker: str,
    lease_seconds: int,
    headless: bool,
    nav_timeout_ms: int,
    wait_after_load_ms: int,
    job_timeout_ms: int,
    max_attempts: int,
    ignore_https_errors: bool,
    heartbeat_seconds: int,
) -> None:
    worker_main(
        db_path=Path(db),
        browser_executable=browser,
        screenshots_dir=Path(screenshots),
        workers_name=worker,
        lease_seconds=lease_seconds,
        headless=headless,
        nav_timeout_ms=nav_timeout_ms,
        wait_after_load_ms=wait_after_load_ms,
        job_timeout_ms=job_timeout_ms,
        max_attempts=max_attempts,
        ignore_https_errors=ignore_https_errors,
        heartbeat_seconds=heartbeat_seconds,
    )


def parse_args() -> argparse.Namespace:
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument("--config", default="config.yaml")
    pre_args, _ = pre.parse_known_args()
    cfg = parse_simple_config(Path(pre_args.config))

    p = argparse.ArgumentParser(description="Run URL screenshot batch with crash-safe progress (SQLite + leases).")
    p.add_argument("--config", default=pre_args.config, help="Path to config.yaml")

    p.add_argument("--db", help="Reuse an existing run DB instead of creating a new one.")
    p.add_argument("--run-name", default="", help="Optional name for this run (used for DB + screenshots folder).")

    p.add_argument("--browser", default=str(cfg.get("browser", "")), help="Path to custom Chromium executable (optional).")
    p.add_argument("--workers", type=int, default=int(cfg.get("workers", 2)), help="Number of worker processes.")
    p.add_argument("--no-reaper", action="store_true", help="Disable reaper process.")
    p.add_argument("--reaper-interval", type=int, default=int(cfg.get("reaper_interval", 15)), help="Seconds between reaper passes.")
    p.add_argument("--stale-seconds", type=int, default=int(cfg.get("stale_seconds", 900)), help="Heartbeat silence threshold.")

    p.add_argument("--lease-seconds", type=int, default=int(cfg.get("lease_seconds", 300)), help="Job lease duration in seconds.")
    p.add_argument("--heartbeat-seconds", type=int, default=int(cfg.get("heartbeat_seconds", 30)))
    p.add_argument("--headful", action="store_true", help="Run with visible browser windows.")
    p.add_argument("--nav-timeout-ms", type=int, default=int(cfg.get("nav_timeout_ms", 45000)))
    p.add_argument("--wait-after-load-ms", type=int, default=int(cfg.get("wait_after_load_ms", 1000)))
    p.add_argument("--job-timeout-ms", type=int, default=int(cfg.get("job_timeout_ms", 120000)))
    p.add_argument("--max-attempts", type=int, default=int(cfg.get("max_attempts", 3)))
    p.add_argument("--ignore-https-errors", action="store_true", default=bool(cfg.get("ignore_https_errors", True)))

    args = p.parse_args()

    if not args.db:
        args.csv = ""
    if int(args.stale_seconds) > int(args.lease_seconds):
        p.error("--stale-seconds must be <= --lease-seconds")

    args._cfg = cfg
    return args


def main() -> int:
    args = parse_args()
    ensure_dirs()

    cfg = getattr(args, "_cfg", {})
    browser = args.browser.strip() or None
    headless = not args.headful if args.headful else bool(cfg.get("headless", True))

    # Decide run identity
    run_name = args.run_name.strip() or ts_name()

    log_path = Path("out/logs") / f"{run_name or 'run'}.log"
    log_file = log_path.open("a", encoding="utf-8")
    last_summary = time.monotonic()

    try:
        if args.db:
            db_path = Path(args.db)
            if not db_path.exists():
                log_line(log_file, f"DB not found: {db_path}")
                return 2

            # If resuming, keep screenshots in a folder derived from DB filename if possible
            inferred = db_path.stem
            shots_dir = Path("out/screenshots") / inferred
            shots_dir.mkdir(parents=True, exist_ok=True)

            log_line(log_file, f"Resuming run DB: {db_path}")
            log_line(log_file, f"Screenshots dir: {shots_dir}")

        else:
            # Create a fresh run
            db_path = Path("out/runs") / f"{run_name}.db"
            shots_dir = Path("out/screenshots") / run_name
            shots_dir.mkdir(parents=True, exist_ok=True)

            log_line(log_file, f"Creating new run DB: {db_path}")
            init_db(db_path)

            files, inserted, skipped = load_urls_from_dir(db_path, Path("data"))
            if files == 0:
                log_line(log_file, "No CSV files found in data/")
                return 2
            log_line(log_file, f"Loaded CSVs: files={files} inserted={inserted}, skipped={skipped}")
            log_line(log_file, f"Screenshots dir: {shots_dir}")

        procs: dict[str, Process] = {}

        def start_reaper() -> None:
            rp = Process(
                target=reaper_main,
                args=(db_path, args.reaper_interval, args.stale_seconds),
                name="reaper",
                daemon=True,
            )
            rp.start()
            procs["reaper"] = rp
            log_line(log_file, f"Started reaper (interval={args.reaper_interval}s) pid={rp.pid}")

        def start_worker(name: str) -> None:
            wp = Process(
                target=worker_entry,
                args=(
                    str(db_path),
                    browser,
                    str(shots_dir),
                    name,
                    args.lease_seconds,
                    headless,
                    args.nav_timeout_ms,
                    args.wait_after_load_ms,
                    args.job_timeout_ms,
                    args.max_attempts,
                    args.ignore_https_errors,
                    args.heartbeat_seconds,
                ),
                name=name,
            )
            wp.start()
            procs[name] = wp
            log_line(log_file, f"Started worker {name} pid={wp.pid}")

        if not args.no_reaper:
            start_reaper()

        w = max(1, int(args.workers))
        for i in range(w):
            start_worker(f"w{i+1}")
            time.sleep(0.2)

        exit_code = 0
        while True:
            with connect(db_path) as conn:
                remaining = count_remaining(conn)
                ready = count_ready(conn)

            if remaining == 0:
                # wait for workers to exit
                all_done = True
                for name, proc in procs.items():
                    if name == "reaper":
                        continue
                    if proc.is_alive():
                        all_done = False
                        break
                if all_done:
                    break

            # Ensure reaper stays alive while there is work
            if not args.no_reaper and remaining > 0:
                rp = procs.get("reaper")
                if rp is None or not rp.is_alive():
                    start_reaper()

            for name, proc in list(procs.items()):
                if name == "reaper":
                    continue
                if proc.is_alive():
                    continue

                if proc.exitcode not in (0, None):
                    exit_code = 1
                    log_line(log_file, f"Worker {name} exited with {proc.exitcode}")

                if remaining > 0 and ready > 0:
                    start_worker(name)

            now = time.monotonic()
            if now - last_summary >= 30:
                last_summary = now
                log_line(log_file, f"Progress: remaining={remaining} ready={ready}")

            time.sleep(1)

        log_line(log_file, "Workers finished.")
        log_line(log_file, f"Run DB: {db_path}")
        log_line(log_file, f"Screenshots: {shots_dir}")
        return exit_code
    finally:
        log_file.close()


if __name__ == "__main__":
    raise SystemExit(main())
