from __future__ import annotations

import time
from pathlib import Path

# Allow running as a script: `python runner/reaper_loop.py`
if __name__ == "__main__" and __package__ is None:
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from runner.core.db import connect, reap_stale_in_progress, reap_stuck_in_progress


def main(db_path: Path, interval_seconds: int = 30, stale_seconds: int = 900) -> None:
    with connect(db_path) as conn:
        last_tick = time.monotonic()
        while True:
            now_tick = time.monotonic()
            # If the machine slept or the process stalled, skip one sweep to avoid false reaps.
            if now_tick - last_tick > max(5 * interval_seconds, 120):
                last_tick = now_tick
                time.sleep(interval_seconds)
                continue
            last_tick = now_tick
            rescued = reap_stale_in_progress(conn)
            stuck = reap_stuck_in_progress(conn, stale_seconds=stale_seconds)
            if rescued or stuck:
                total = rescued + stuck
                print(f"[reaper] rescued {total} stuck jobs (lease={rescued}, heartbeat={stuck})")
            time.sleep(interval_seconds)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    p.add_argument("--interval", type=int, default=30)
    p.add_argument("--stale-seconds", type=int, default=900, help="Heartbeat silence threshold")
    args = p.parse_args()
    main(Path(args.db), args.interval, args.stale_seconds)
