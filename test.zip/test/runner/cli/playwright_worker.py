from __future__ import annotations

import hashlib
import os
import random
import threading
import time
import multiprocessing as mp
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

# Allow running as a script: `python runner/playwright_worker.py`
if __name__ == "__main__" and __package__ is None:
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError, Error as PWError

from runner.core.db import (
    connect,
    claim_job,
    heartbeat,
    mark_done,
    mark_failed,
    get_domain_backoff,
    record_domain_failure,
    record_domain_success,
    check_global_backoff,
    record_global_result,
    defer_job,
    count_ready,
)


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()


def screenshot_path_for(out_dir: Path, url: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir / f"{sha256_hex(url)}.png"


def is_valid_png(path: Path) -> bool:
    try:
        if not path.exists() or not path.is_file():
            return False
        if path.stat().st_size < 8:
            return False
        with path.open("rb") as f:
            sig = f.read(8)
        return sig == b"\x89PNG\r\n\x1a\n"
    except Exception:
        return False


def url_domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


def classify_permanent(url: str, err: Exception) -> bool:
    # Keep this conservative: most things are transient.
    msg = str(err).lower()

    # obvious bad inputs
    if "invalid url" in msg or "cannot navigate to invalid url" in msg:
        return True

    # If you want, treat DNS issues as permanent-ish. Often they aren't, so optional.
    # if "name not resolved" in msg or "nxdomain" in msg:
    #     return True

    return False


def run_job(
    browser_executable: Optional[str],
    headless: bool,
    url: str,
    out_dir: Path,
    nav_timeout_ms: int,
    wait_after_load_ms: int,
    ignore_https_errors: bool,
) -> tuple[str, int]:
    """
    Returns (final_url, load_ms). Raises on failure.
    """
    with sync_playwright() as p:
        # Use chromium engine but point to custom build if provided
        launch_kwargs = {
            "headless": headless,
        }
        if browser_executable:
            launch_kwargs["executable_path"] = browser_executable

        browser = p.chromium.launch(**launch_kwargs)

        try:
            context = browser.new_context(ignore_https_errors=ignore_https_errors)
            page = context.new_page()

            page.set_default_navigation_timeout(nav_timeout_ms)
            page.set_default_timeout(nav_timeout_ms)

            t0 = time.time()
            page.goto(url, wait_until="domcontentloaded")
            # Some pages never reach networkidle. Don't depend on it.
            # If you want a tiny extra wait for rendering:
            if wait_after_load_ms > 0:
                page.wait_for_timeout(wait_after_load_ms)

            final = page.url
            load_ms = int((time.time() - t0) * 1000)

            shot_path = screenshot_path_for(out_dir, url)
            page.screenshot(path=str(shot_path), full_page=True)

            context.close()
            return final, load_ms
        finally:
            browser.close()


def _run_job_process(args, queue) -> None:
    try:
        final_url, load_ms = run_job(**args)
        queue.put(("ok", final_url, load_ms))
    except Exception as e:
        queue.put(("err", type(e).__name__, str(e)))


def run_job_with_timeout(
    *,
    browser_executable: Optional[str],
    headless: bool,
    url: str,
    out_dir: Path,
    nav_timeout_ms: int,
    wait_after_load_ms: int,
    ignore_https_errors: bool,
    job_timeout_ms: int,
) -> tuple[str, int]:
    ctx = mp.get_context("spawn")
    q: mp.Queue = ctx.Queue()
    args = {
        "browser_executable": browser_executable,
        "headless": headless,
        "url": url,
        "out_dir": out_dir,
        "nav_timeout_ms": nav_timeout_ms,
        "wait_after_load_ms": wait_after_load_ms,
        "ignore_https_errors": ignore_https_errors,
    }
    p = ctx.Process(target=_run_job_process, args=(args, q), daemon=True)
    p.start()
    p.join(timeout=job_timeout_ms / 1000)
    if p.is_alive():
        p.terminate()
        p.join(timeout=5)
        raise TimeoutError(f"job timeout after {job_timeout_ms}ms")

    if q.empty():
        raise RuntimeError("job worker exited without result")
    status, a, b = q.get()
    if status == "ok":
        return a, b
    if status == "err":
        exc_type, msg = a, b
        if exc_type in ("TimeoutError", "PlaywrightTimeoutError", "PWTimeoutError"):
            raise PWTimeoutError(msg)
        raise RuntimeError(f"{exc_type}: {msg}")
    raise RuntimeError("unexpected job worker result")

def heartbeat_loop(
    db_path: Path,
    job_id: int,
    lease_id: str,
    lease_seconds: int,
    interval_seconds: int,
    stop_event: threading.Event,
    stale_event: threading.Event,
) -> None:
    with connect(db_path) as conn:
        while not stop_event.is_set():
            ok = heartbeat(conn, job_id=job_id, lease_id=lease_id, lease_seconds=lease_seconds)
            if not ok:
                stale_event.set()
                break
            stop_event.wait(interval_seconds)


def main(
    db_path: Path,
    browser_executable: Optional[str],
    screenshots_dir: Path,
    workers_name: str,
    lease_seconds: int = 300,
    heartbeat_seconds: int = 30,
    headless: bool = True,
    nav_timeout_ms: int = 45000,
    wait_after_load_ms: int = 1000,
    job_timeout_ms: int = 120000,
    ignore_https_errors: bool = True,
    max_attempts: int = 3,
    domain_backoff_base: int = 5,
    domain_backoff_max: int = 300,
    domain_backoff_reset_seconds: int = 900,
    global_window_seconds: int = 60,
    global_failure_rate: float = 0.7,
    global_min_samples: int = 10,
    global_backoff_seconds: int = 30,
) -> None:
    screenshots_dir.mkdir(parents=True, exist_ok=True)

    with connect(db_path) as conn:
        while True:
            global_wait = check_global_backoff(conn)
            if global_wait > 0:
                ready = count_ready(conn)
                sleep_for = min(global_wait, 5 if ready > 0 else 15)
                time.sleep(sleep_for)
                continue

            job = claim_job(conn, lease_seconds=lease_seconds)
            if not job:
                print(f"[{workers_name}] no more jobs")
                break

            print(f"[{workers_name}] #{job.id} {job.url}")
            domain = url_domain(job.url)
            if domain:
                domain_wait = get_domain_backoff(conn, domain)
                if domain_wait > 0:
                    defer_job(
                        conn,
                        job.id,
                        job.lease_id,
                        backoff_seconds=domain_wait,
                        reason=f"domain backoff: {domain}",
                    )
                    time.sleep(min(domain_wait, 1))
                    continue

            # Idempotency: if screenshot already exists and is valid, mark done.
            shot_path = screenshot_path_for(screenshots_dir, job.url)
            if is_valid_png(shot_path):
                ok = mark_done(
                    conn,
                    job.id,
                    job.lease_id,
                    screenshot_path=str(shot_path),
                    final_url=job.url,
                    load_ms=None,
                )
                if ok:
                    if domain:
                        record_domain_success(conn, domain)
                    record_global_result(
                        conn,
                        success=True,
                        window_seconds=global_window_seconds,
                        failure_rate=global_failure_rate,
                        min_samples=global_min_samples,
                        backoff_seconds=global_backoff_seconds,
                    )
                    print(f"[{workers_name}] DONE #{job.id} (cached)")
                else:
                    print(f"[{workers_name}] STALE #{job.id} (not committed)")
                continue

            stop_event = threading.Event()
            stale_event = threading.Event()
            hb = threading.Thread(
                target=heartbeat_loop,
                args=(db_path, job.id, job.lease_id, lease_seconds, heartbeat_seconds, stop_event, stale_event),
                name=f"hb-{workers_name}-{job.id}",
                daemon=True,
            )
            hb.start()

            try:
                final_url, load_ms = run_job_with_timeout(
                    browser_executable=browser_executable,
                    headless=headless,
                    url=job.url,
                    out_dir=screenshots_dir,
                    nav_timeout_ms=nav_timeout_ms,
                    wait_after_load_ms=wait_after_load_ms,
                    job_timeout_ms=job_timeout_ms,
                    ignore_https_errors=ignore_https_errors,
                )

                if stale_event.is_set():
                    print(f"[{workers_name}] STALE #{job.id} (lease lost during run)")
                else:
                    ok = mark_done(
                        conn,
                        job.id,
                        job.lease_id,
                        screenshot_path=str(shot_path),
                        final_url=final_url,
                        load_ms=load_ms,
                    )
                    if ok:
                        if domain:
                            record_domain_success(conn, domain)
                        record_global_result(
                            conn,
                            success=True,
                            window_seconds=global_window_seconds,
                            failure_rate=global_failure_rate,
                            min_samples=global_min_samples,
                            backoff_seconds=global_backoff_seconds,
                        )
                        print(f"[{workers_name}] DONE #{job.id} ({load_ms}ms)")
                    else:
                        print(f"[{workers_name}] STALE #{job.id} (not committed)")

                # gentle jitter so you don't hammer servers in sync
                time.sleep(random.uniform(0.1, 0.4))

            except (PWTimeoutError,) as e:
                # navigation timeout: usually transient
                if stale_event.is_set():
                    print(f"[{workers_name}] STALE #{job.id} (lease lost during run)")
                else:
                    backoff = record_domain_failure(
                        conn,
                        domain,
                        base_seconds=domain_backoff_base,
                        max_seconds=domain_backoff_max,
                        reset_after_seconds=domain_backoff_reset_seconds,
                    ) if domain else 30
                    global_wait = record_global_result(
                        conn,
                        success=False,
                        window_seconds=global_window_seconds,
                        failure_rate=global_failure_rate,
                        min_samples=global_min_samples,
                        backoff_seconds=global_backoff_seconds,
                    )
                    backoff = max(backoff, global_wait, 30)

                    ok = mark_failed(
                        conn,
                        job.id,
                        job.lease_id,
                        error=f"timeout: {e}",
                        permanent=False,
                        backoff_seconds=backoff,
                        max_attempts=max_attempts,
                    )
                    if ok:
                        print(f"[{workers_name}] RETRY #{job.id} timeout")
                    else:
                        print(f"[{workers_name}] STALE #{job.id} (not committed)")

            except (PWError, Exception) as e:
                permanent = classify_permanent(job.url, e)
                backoff = 30 if not permanent else 0
                if stale_event.is_set():
                    print(f"[{workers_name}] STALE #{job.id} (lease lost during run)")
                else:
                    backoff = record_domain_failure(
                        conn,
                        domain,
                        base_seconds=domain_backoff_base,
                        max_seconds=domain_backoff_max,
                        reset_after_seconds=domain_backoff_reset_seconds,
                    ) if domain else 30
                    global_wait = record_global_result(
                        conn,
                        success=False,
                        window_seconds=global_window_seconds,
                        failure_rate=global_failure_rate,
                        min_samples=global_min_samples,
                        backoff_seconds=global_backoff_seconds,
                    )
                    if permanent:
                        backoff = 0
                    else:
                        backoff = max(backoff, global_wait, 30)

                    ok = mark_failed(
                        conn,
                        job.id,
                        job.lease_id,
                        error=f"{type(e).__name__}: {e}",
                        permanent=permanent,
                        backoff_seconds=backoff,
                        max_attempts=max_attempts,
                    )
                    if ok:
                        print(f"[{workers_name}] {'FAILED' if permanent else 'RETRY'} #{job.id}: {e}")
                    else:
                        print(f"[{workers_name}] STALE #{job.id} (not committed)")
            finally:
                stop_event.set()
                hb.join(timeout=2)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Playwright screenshot worker (lease-based).")
    p.add_argument("--db", required=True, help="Path to run DB")
    p.add_argument("--browser", default="", help="Path to custom Chromium executable (optional)")
    p.add_argument("--screenshots", default="out/screenshots", help="Output screenshot folder")
    p.add_argument("--worker", default=f"w{os.getpid()}")
    p.add_argument("--headful", action="store_true", help="Run with a visible browser window")
    p.add_argument("--heartbeat-seconds", type=int, default=30, help="Lease heartbeat interval in seconds")
    p.add_argument("--nav-timeout-ms", type=int, default=45000)
    p.add_argument("--wait-after-load-ms", type=int, default=1000)
    p.add_argument("--job-timeout-ms", type=int, default=120000, help="Hard per-job timeout")
    p.add_argument("--max-attempts", type=int, default=3)
    p.add_argument("--domain-backoff-base", type=int, default=5)
    p.add_argument("--domain-backoff-max", type=int, default=300)
    p.add_argument("--domain-backoff-reset-seconds", type=int, default=900)
    p.add_argument("--global-window-seconds", type=int, default=60)
    p.add_argument("--global-failure-rate", type=float, default=0.7)
    p.add_argument("--global-min-samples", type=int, default=10)
    p.add_argument("--global-backoff-seconds", type=int, default=30)
    args = p.parse_args()

    main(
        db_path=Path(args.db),
        browser_executable=args.browser or None,
        screenshots_dir=Path(args.screenshots),
        workers_name=args.worker,
        headless=not args.headful,
        heartbeat_seconds=args.heartbeat_seconds,
        nav_timeout_ms=args.nav_timeout_ms,
        wait_after_load_ms=args.wait_after_load_ms,
        job_timeout_ms=args.job_timeout_ms,
        max_attempts=args.max_attempts,
        domain_backoff_base=args.domain_backoff_base,
        domain_backoff_max=args.domain_backoff_max,
        domain_backoff_reset_seconds=args.domain_backoff_reset_seconds,
        global_window_seconds=args.global_window_seconds,
        global_failure_rate=args.global_failure_rate,
        global_min_samples=args.global_min_samples,
        global_backoff_seconds=args.global_backoff_seconds,
    )
