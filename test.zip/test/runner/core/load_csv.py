# load_csv.py
from __future__ import annotations

import csv
import re
import sqlite3
from pathlib import Path
from urllib.parse import urlparse


def normalize_url(raw: str) -> str | None:
    if not raw:
        return None
    u = raw.strip().strip('"').strip("'")
    if not u:
        return None

    # if someone wrote "example.com" instead of "https://example.com"
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        u = "https://" + u

    try:
        p = urlparse(u)
    except Exception:
        return None

    if not p.scheme or not p.netloc:
        return None

    # Normalize: remove trailing spaces, keep as-is otherwise
    return u


def load_urls(db_path: Path, csv_path: Path) -> tuple[int, int]:
    inserted = 0
    skipped = 0

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        with csv_path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        if not rows:
            return (0, 0)

        # Detect header with "url"
        header = [c.strip().lower() for c in rows[0]]
        url_idx = header.index("url") if "url" in header else 0

        for i, row in enumerate(rows[1:] if "url" in header else rows, start=1):
            if not row:
                skipped += 1
                continue

            raw = row[url_idx] if url_idx < len(row) else ""
            url = normalize_url(raw)
            if not url:
                skipped += 1
                continue

            # idempotent insert
            cur.execute(
                "INSERT OR IGNORE INTO jobs(url, status) VALUES(?, 'PENDING')",
                (url,),
            )
            if cur.rowcount == 1:
                inserted += 1

        conn.commit()

    return (inserted, skipped)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Load URLs from CSV into the run DB.")
    p.add_argument("--db", required=True, help="Path to SQLite DB file.")
    p.add_argument("--csv", required=True, help="Path to input CSV containing URLs.")
    args = p.parse_args()

    ins, sk = load_urls(Path(args.db), Path(args.csv))
    print(f"Inserted: {ins} | Skipped: {sk}")