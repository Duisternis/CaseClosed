#!/usr/bin/env bash
set -euo pipefail

MAX_RESTARTS=5
RESTART_DELAY=5

count=0
while true; do
  echo "[runner] starting (attempt $((count + 1))/${MAX_RESTARTS})"
  python main.py "$@"
  exit_code=$?

  if [ $exit_code -eq 0 ]; then
    echo "[runner] completed successfully"
    exit 0
  fi

  count=$((count + 1))
  if [ $count -ge $MAX_RESTARTS ]; then
    echo "[runner] reached max restarts (${MAX_RESTARTS}), exiting with code ${exit_code}"
    exit $exit_code
  fi

  echo "[runner] exited with code ${exit_code}, restarting in ${RESTART_DELAY}s..."
  sleep $RESTART_DELAY
done
