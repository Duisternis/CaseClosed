#!/usr/bin/env python3
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "out"


def _relpath(p: Path) -> str:
    try:
        return str(p.relative_to(OUT))
    except Exception:
        return str(p)


def tail_lines(path: Path, max_lines: int = 200) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        if len(lines) > max_lines:
            return lines[-max_lines:]
        return lines
    except Exception as e:
        return [f"<error reading log: {e}>"]


def db_stats(db_path: Path) -> dict[str, Any]:
    stats: dict[str, Any] = {
        "path": _relpath(db_path),
        "name": db_path.stem,
        "counts": {},
        "total": 0,
        "min_created": None,
        "max_updated": None,
        "events": [],
    }
    try:
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            cur.execute("SELECT status, COUNT(*) FROM jobs GROUP BY status;")
            rows = cur.fetchall()
            total = 0
            counts = {}
            for s, c in rows:
                counts[str(s)] = int(c)
                total += int(c)
            stats["counts"] = counts
            stats["total"] = total
            cur.execute("SELECT MIN(created_at_utc), MAX(updated_at_utc) FROM jobs;")
            r = cur.fetchone()
            if r:
                stats["min_created"] = r[0]
                stats["max_updated"] = r[1]
            events = []
            try:
                cur.execute(
                    "SELECT job_id, event_type, message, lease_id, created_at_utc "
                    "FROM job_events ORDER BY id DESC LIMIT 30;"
                )
                for job_id, event_type, message, lease_id, created_at_utc in cur.fetchall():
                    events.append(
                        {
                            "job_id": job_id,
                            "event_type": event_type,
                            "message": message,
                            "lease_id": lease_id,
                            "created_at_utc": created_at_utc,
                        }
                    )
            except sqlite3.OperationalError:
                pass
            stats["events"] = events
    except Exception as e:
        stats["error"] = str(e)
    return stats


def collect() -> dict[str, Any]:
    data: dict[str, Any] = {"runs": [], "logs": [], "screenshots": []}

    runs_dir = OUT / "runs"
    logs_dir = OUT / "logs"
    shots_dir = OUT / "screenshots"

    if runs_dir.exists():
        for db in sorted(runs_dir.glob("*.db")):
            data["runs"].append(db_stats(db))

    if logs_dir.exists():
        for log in sorted(logs_dir.glob("*.log")):
            data["logs"].append(
                {
                    "name": log.name,
                    "path": _relpath(log),
                    "lines": tail_lines(log, 200),
                }
            )

    if shots_dir.exists():
        for run_dir in sorted(p for p in shots_dir.iterdir() if p.is_dir()):
            files = sorted(run_dir.glob("*.png"))
            rel_files = [_relpath(f) for f in files]
            data["screenshots"].append(
                {
                    "name": run_dir.name,
                    "path": _relpath(run_dir),
                    "count": len(files),
                    "files": rel_files,
                }
            )

    return data


def render_html(data: dict[str, Any]) -> str:
    payload = json.dumps(data, ensure_ascii=True)
    html = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Run Inspector</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      color: #111;
      background: #fff;
    }
    header {
      padding: 14px 16px;
      border-bottom: 2px solid #111;
    }
    h1 { margin: 0; font-size: 18px; }
    .sub { color: #444; font-size: 12px; margin-top: 4px; }
    .wrap { padding: 14px; }
    .tabs { display: flex; gap: 8px; margin: 10px 0; }
    .tab { border: 2px solid #111; padding: 4px 8px; cursor: pointer; }
    .tab.active { background: #111; color: #fff; }
    .section { margin-top: 10px; }
    .title { font-weight: 700; margin-bottom: 8px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 10px; }
    .card { border: 2px solid #111; padding: 10px; background: #fff; }
    .pill { border: 2px solid #111; padding: 2px 6px; font-size: 11px; display: inline-block; margin-left: 6px; }
    .stat { border: 1px solid #111; padding: 2px 6px; font-size: 11px; display: inline-block; margin: 2px 4px 0 0; }
    .k { color: #444; font-size: 11px; }
    .events { max-height: 180px; overflow: auto; border-top: 1px solid #111; margin-top: 8px; padding-top: 6px; }
    .evt { font-size: 11px; padding: 4px 0; border-bottom: 1px dashed #aaa; }
    .logbox { border: 1px solid #111; padding: 8px; font-size: 11px; white-space: pre-wrap; max-height: 220px; overflow: auto; }
    .shots { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 8px; }
    .shot { border: 1px solid #111; padding: 4px; }
    .shot img { width: 100%; height: 90px; object-fit: cover; display: block; }
    .shot .cap { font-size: 10px; margin-top: 4px; word-break: break-all; }
    .warn { color: #b00020; font-size: 12px; }
    .toolbar { display: flex; gap: 8px; align-items: center; font-size: 11px; margin-top: 6px; }
    button { border: 2px solid #111; background: #fff; padding: 2px 6px; cursor: pointer; }
    .help { border-top: 1px solid #111; margin-top: 10px; padding-top: 8px; font-size: 11px; color: #333; }
    .help summary { cursor: pointer; }
    .help .line { margin: 4px 0; }
    .row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    input[type="number"] { width: 80px; }
  </style>
</head>
<body>
  <header>
    <h1>Run Inspector</h1>
    <div class="sub">Runs, logs, screenshots from <code>out/</code>. Minimal debug view.</div>
    <div class="toolbar">
      <span id="status">ready</span>
      <button id="refreshBtn">refresh</button>
      <span class="k">auto refresh every 5s (server only)</span>
    </div>
  </header>
  <div class="wrap">
    <div class="tabs">
      <div class="tab active" data-tab="runs">Runs</div>
      <div class="tab" data-tab="logs">Logs</div>
      <div class="tab" data-tab="shots">Screenshots</div>
    </div>
    <div id="root"></div>
  </div>

  <script>
    const EMBEDDED = __PAYLOAD__;
    let DATA = EMBEDDED;
    const root = document.getElementById('root');
    const statusEl = document.getElementById('status');
    const refreshBtn = document.getElementById('refreshBtn');
    const tabs = Array.from(document.querySelectorAll('.tab'));
    let activeTab = 'runs';

    function h(tag, cls, text) {
      const n = document.createElement(tag);
      if (cls) n.className = cls;
      if (text !== undefined) n.textContent = text;
      return n;
    }

    function renderRuns() {
      const wrap = h('div', 'section');
      const header = h('div', 'row');
      header.appendChild(h('div', 'title', 'Runs'));
      wrap.appendChild(header);

      const help = document.createElement('details');
      help.className = 'help';
      const sum = document.createElement('summary');
      sum.textContent = 'Legend (plain English)';
      help.appendChild(sum);
      const l1 = h('div', 'line', 'Status: PENDING = waiting. IN_PROGRESS = being worked (leased). RETRY_WAIT = failed once, waiting before retry. FAILED = gave up. DONE = finished.');
      const l2 = h('div', 'line', 'Lease: temporary lock so only one worker handles a job. Heartbeat: worker says \"I am alive\" to keep the lease.');
      const l3 = h('div', 'line', 'Reaper: safety process that returns stuck jobs back to the queue.');
      const l4 = h('div', 'line', 'Events: CLAIM (worker took job), HEARTBEAT (renewed lease), DONE, FAILED, RETRY_WAIT, DEFER (delayed by backoff), REAP (requeued).');
      help.appendChild(l1);
      help.appendChild(l2);
      help.appendChild(l3);
      help.appendChild(l4);
      wrap.appendChild(help);

      if (!DATA.runs.length) {
        wrap.appendChild(h('div', 'warn', 'No DB runs found.'));
        return wrap;
      }

      const grid = h('div', 'grid');
      for (const r of DATA.runs) {
        const card = h('div', 'card');
        const head = h('div', 'row');
        head.appendChild(h('div', null, r.name));
        head.appendChild(h('span', 'pill', `${r.total || 0} jobs`));
        card.appendChild(head);
        if (r.error) card.appendChild(h('div', 'warn', `DB error: ${r.error}`));
        const counts = r.counts || {};
        for (const k of Object.keys(counts)) {
          card.appendChild(h('span', 'stat', `${k}: ${counts[k]}`));
        }
        card.appendChild(h('div', 'k', `Created: ${r.min_created || '-'} | Updated: ${r.max_updated || '-'}`));

        const ev = h('div', 'events');
        ev.setAttribute('data-events', r.name);
        if (r.events && r.events.length) {
          for (const e of r.events) {
            ev.appendChild(h('div', 'evt', `${e.event_type} #${e.job_id} ${e.message || ''} ${e.created_at_utc || ''}`));
          }
        } else {
          ev.appendChild(h('div', 'k', 'No events recorded.'));
        }
        card.appendChild(ev);
        grid.appendChild(card);
      }
      wrap.appendChild(grid);
      return wrap;
    }

    function renderLogs() {
      const wrap = h('div', 'section');
      wrap.appendChild(h('div', 'title', 'Logs'));
      if (!DATA.logs.length) {
        wrap.appendChild(h('div', 'warn', 'No logs found.'));
        return wrap;
      }
      const grid = h('div', 'grid');
      for (const l of DATA.logs) {
        const card = h('div', 'card');
        card.appendChild(h('div', null, l.name));
        const box = h('div', 'logbox', (l.lines || []).join('\\n'));
        card.appendChild(box);
        grid.appendChild(card);
      }
      wrap.appendChild(grid);
      return wrap;
    }

    function renderShots() {
      const wrap = h('div', 'section');
      const header = h('div', 'row');
      header.appendChild(h('div', 'title', 'Screenshots'));
      const limitLabel = h('div', 'k', 'per run');
      const limitInput = document.createElement('input');
      limitInput.type = 'number';
      limitInput.min = '1';
      limitInput.max = '100';
      limitInput.value = '12';
      header.appendChild(h('div', 'k', 'show'));
      header.appendChild(limitInput);
      header.appendChild(limitLabel);
      wrap.appendChild(header);

      if (!DATA.screenshots.length) {
        wrap.appendChild(h('div', 'warn', 'No screenshots found.'));
        return wrap;
      }

      const list = h('div');
      for (const s of DATA.screenshots) {
        const card = h('div', 'card');
        card.appendChild(h('div', null, `${s.name} (${s.count})`));
        const grid = h('div', 'shots');
        const limit = Math.max(1, parseInt(limitInput.value || '12', 10));
        for (const f of s.files.slice(0, limit)) {
          const item = h('div', 'shot');
          const img = document.createElement('img');
          img.src = f;
          const cap = h('div', 'cap', f.split('/').pop());
          item.appendChild(img);
          item.appendChild(cap);
          grid.appendChild(item);
        }
        if (s.files.length > limit) {
          card.appendChild(h('div', 'k', `Showing ${limit} of ${s.files.length}`));
        }
        card.appendChild(grid);
        list.appendChild(card);
      }
      wrap.appendChild(list);

      limitInput.addEventListener('change', () => {
        render();
      });

      return wrap;
    }

    function captureEventScroll() {
      const map = {};
      document.querySelectorAll('[data-events]').forEach(el => {
        map[el.getAttribute('data-events')] = el.scrollTop;
      });
      return map;
    }

    function restoreEventScroll(map) {
      document.querySelectorAll('[data-events]').forEach(el => {
        const key = el.getAttribute('data-events');
        if (map && map[key] !== undefined) el.scrollTop = map[key];
      });
    }

    function render() {
      const prevLegendOpen = document.querySelector('details.help')?.open;
      const prevScroll = root.scrollTop;
      const prevEventScroll = captureEventScroll();
      root.innerHTML = '';
      if (activeTab === 'runs') root.appendChild(renderRuns());
      if (activeTab === 'logs') root.appendChild(renderLogs());
      if (activeTab === 'shots') root.appendChild(renderShots());
      const details = document.querySelector('details.help');
      if (details && prevLegendOpen) details.open = true;
      restoreEventScroll(prevEventScroll);
      root.scrollTop = prevScroll;
    }

    async function refresh() {
      try {
        if (location.protocol.startsWith('http')) {
          statusEl.textContent = 'refreshing...';
          const res = await fetch('data.json?_=' + Date.now());
          const next = await res.json();
          DATA = next;
          render();
          statusEl.textContent = 'ok';
        } else {
          render();
          statusEl.textContent = 'file mode';
        }
      } catch (e) {
        statusEl.textContent = 'error';
      }
    }

    refreshBtn.addEventListener('click', refresh);
    tabs.forEach(t => t.addEventListener('click', () => {
      tabs.forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      activeTab = t.dataset.tab;
      render();
    }));

    render();
    if (location.protocol.startsWith('http')) {
      setInterval(refresh, 5000);
    }
  </script>
</body>
</html>"""
    return html.replace("__PAYLOAD__", payload)


def main() -> int:
    data = collect()
    OUT.mkdir(parents=True, exist_ok=True)
    html = render_html(data)
    (OUT / "index.html").write_text(html, encoding="utf-8")
    (OUT / "data.json").write_text(json.dumps(data, ensure_ascii=True), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
