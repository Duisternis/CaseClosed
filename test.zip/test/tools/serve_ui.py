#!/usr/bin/env python3
from __future__ import annotations

import functools
import http.server
import socketserver
import argparse
import threading
import time
from pathlib import Path

from build_ui import main as build

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "out"


def rebuild_loop(interval: int) -> None:
    while True:
        try:
            build()
        except Exception as e:
            print(f"[ui] build failed: {e}")
        time.sleep(interval)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--interval", type=int, default=5)
    args = p.parse_args()

    host = args.host
    port = args.port
    interval = args.interval

    OUT.mkdir(parents=True, exist_ok=True)
    build()

    t = threading.Thread(target=rebuild_loop, args=(interval,), daemon=True)
    t.start()

    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(OUT))
    class ReuseTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    with ReuseTCPServer((host, port), handler) as httpd:
        print(f"[ui] serving {OUT} at http://{host}:{port}/index.html")
        print(f"[ui] auto-rebuild every {interval}s")
        httpd.serve_forever()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
